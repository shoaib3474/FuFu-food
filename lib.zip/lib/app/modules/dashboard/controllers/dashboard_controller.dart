import 'package:get/get.dart';

class DashboardController extends GetxController {
  @override
  // ignore: unnecessary_overrides
  void onInit() {
    super.onInit();
  }
}
