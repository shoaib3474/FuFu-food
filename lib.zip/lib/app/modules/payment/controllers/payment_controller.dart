import 'package:get/get.dart';

class PaymentController extends GetxController {}
