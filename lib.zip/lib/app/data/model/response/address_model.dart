class AddressModel {
  int? id;
  String? label;
  String? address;
  String? apartment;
  double? latitude;
  double? longitude;

  AddressModel(
      {this.id,
      this.label,
      this.address,
      this.apartment,
      this.latitude,
      this.longitude});
}
